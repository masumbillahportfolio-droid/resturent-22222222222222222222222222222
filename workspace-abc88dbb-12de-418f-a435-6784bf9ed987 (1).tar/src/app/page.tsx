"use client";

import * as React from "react";
import { ShoppingBag, ChevronRight } from "lucide-react";
import { MenuView } from "@/components/rooftop/menu-view";
import { CartSheet, type OrderForm } from "@/components/rooftop/cart-sheet";
import { SuccessModal, type PlacedOrder } from "@/components/rooftop/success-modal";
import { ProductDetailModal } from "@/components/rooftop/product-detail-modal";
import { MENU_ITEMS, formatTaka } from "@/lib/menu-data";

export default function Home() {
  const [cart, setCart] = React.useState<Record<number, number>>({});
  const [cartOpen, setCartOpen] = React.useState(false);
  const [placing, setPlacing] = React.useState(false);
  const [order, setOrder] = React.useState<PlacedOrder | null>(null);
  const [selectedProductId, setSelectedProductId] = React.useState<number | null>(null);
  const [form, setForm] = React.useState<OrderForm>({
    name: "",
    phone: "",
    table: "",
    notes: "",
  });

  const addToCart = (id: number) =>
    setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));

  const inc = (id: number) =>
    setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));

  const dec = (id: number) =>
    setCart((c) => {
      const next = (c[id] || 0) - 1;
      const copy = { ...c };
      if (next <= 0) delete copy[id];
      else copy[id] = next;
      return copy;
    });

  const onFormChange = (patch: Partial<OrderForm>) =>
    setForm((f) => ({ ...f, ...patch }));

  const totalItems = React.useMemo(
    () => Object.values(cart).reduce((sum, q) => sum + q, 0),
    [cart]
  );

  const subtotal = React.useMemo(
    () =>
      Object.entries(cart).reduce((sum, [id, q]) => {
        const item = MENU_ITEMS.find((m) => m.id === Number(id));
        return sum + (item ? item.price * q : 0);
      }, 0),
    [cart]
  );

  const placeOrder = async () => {
    setPlacing(true);
    // Simulate network latency for realism
    await new Promise((r) => setTimeout(r, 1100));
    const orderNumber = String(Math.floor(100000 + Math.random() * 900000));
    const items = Object.entries(cart).map(([id, qty]) => ({ id: Number(id), qty }));
    const deliveryFee = subtotal >= 500 ? 0 : 40;
    setOrder({
      orderNumber,
      items,
      total: subtotal + deliveryFee,
      name: form.name,
      table: form.table,
    });
    setPlacing(false);
    setCartOpen(false);
    setCart({});
    setForm({ name: "", phone: "", table: "", notes: "" });
  };

  const closeSuccess = () => setOrder(null);

  const selectedProduct = selectedProductId
    ? MENU_ITEMS.find((m) => m.id === selectedProductId) ?? null
    : null;

  return (
    <div className="min-h-screen bg-slate-950">
      <MenuView
        cart={cart}
        onAdd={addToCart}
        onOpenCart={() => setCartOpen(true)}
        onOpenProduct={(id) => setSelectedProductId(id)}
      />

      {/* Sticky bottom cart bar */}
      {totalItems > 0 && !cartOpen && !order && !selectedProduct && (
        <div className="animate-float-in fixed inset-x-0 bottom-0 z-30 mx-auto max-w-md px-4 pb-4">
          <button
            onClick={() => setCartOpen(true)}
            className="flex w-full items-center justify-between gap-3 rounded-2xl bg-white px-4 py-3 text-slate-900 shadow-xl shadow-black/40 transition active:scale-[0.98]"
          >
            <div className="flex items-center gap-3">
              <div className="relative grid h-9 w-9 place-items-center rounded-xl bg-red-600 text-white">
                <ShoppingBag size={18} />
                <span className="absolute -right-1.5 -top-1.5 grid h-4 min-w-[16px] place-items-center rounded-full bg-slate-900 px-1 text-[10px] font-bold text-white ring-1 ring-white">
                  {totalItems}
                </span>
              </div>
              <div className="text-left">
                <p className="text-[10.5px] uppercase tracking-wider text-slate-500">মোট</p>
                <p className="text-[15px] font-bold leading-tight">{formatTaka(subtotal)}</p>
              </div>
            </div>
            <div className="flex items-center gap-1 text-[13px] font-semibold">
              কার্ট দেখুন <ChevronRight size={16} />
            </div>
          </button>
        </div>
      )}

      <CartSheet
        open={cartOpen}
        cart={cart}
        form={form}
        onFormChange={onFormChange}
        onInc={inc}
        onDec={dec}
        onClose={() => setCartOpen(false)}
        onPlaceOrder={placeOrder}
        placing={placing}
      />

      <ProductDetailModal
        item={selectedProduct}
        qtyInCart={selectedProduct ? cart[selectedProduct.id] || 0 : 0}
        onClose={() => setSelectedProductId(null)}
        onAdd={addToCart}
        onInc={inc}
        onDec={dec}
      />

      <SuccessModal order={order} onClose={closeSuccess} />
    </div>
  );
}
