import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, Noto_Sans_Bengali } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const notoBengali = Noto_Sans_Bengali({
  variable: "--font-bengali",
  subsets: ["bengali"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "ROOFTOP Restaurant — দ্রুত অর্ডার করুন",
  description: "ROOFTOP Restaurant এ অনলাইন খাবার অর্ডার করুন। ফ্রি ডেলিভারি, দ্রুত সার্ভিস, সুস্বাদু খাবার।",
  keywords: ["ROOFTOP Restaurant", "food order", "online food", "restaurant", "Bengali food app"],
  authors: [{ name: "ROOFTOP Restaurant" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#E63946",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="bn" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${notoBengali.variable} antialiased bg-slate-950 text-white font-bengali`}
        style={{ colorScheme: "dark" }}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
