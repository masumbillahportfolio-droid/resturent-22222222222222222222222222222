"use client";

import * as React from "react";
import Image from "next/image";
import { Search, Plus, ShoppingBag, Bell, MapPin, Star, Clock, ChevronRight } from "lucide-react";
import { CATEGORIES, MENU_ITEMS, TAG_MAP, formatTaka, type CategoryId, type MenuItem } from "@/lib/menu-data";
import { BikeIcon, ClockIcon, StarIcon } from "./icons";

type Props = {
  cart: Record<number, number>;
  onAdd: (id: number) => void;
  onOpenCart: () => void;
  onOpenProduct: (id: number) => void;
};

export function MenuView({ cart, onAdd, onOpenCart, onOpenProduct }: Props) {
  const [category, setCategory] = React.useState<CategoryId>("all");
  const [search, setSearch] = React.useState("");

  const filtered = React.useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      const matchesCat = category === "all" || item.category === category;
      const matchesSearch =
        search.trim() === "" ||
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        item.nameEn.toLowerCase().includes(search.toLowerCase());
      return matchesCat && matchesSearch;
    });
  }, [category, search]);

  const totalItems = React.useMemo(
    () => Object.values(cart).reduce((sum, q) => sum + q, 0),
    [cart]
  );

  return (
    <div className="min-h-screen bg-slate-950 pb-32">
      {/* Top banner: Free delivery */}
      <div className="bg-gradient-to-r from-red-600 to-rose-600 text-white">
        <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-2.5 text-[13px]">
          <div className="flex items-center gap-2 font-medium">
            <BikeIcon size={16} className="shrink-0" />
            <span>ফ্রি ডেলিভারি · ৩০ মিনিটে</span>
          </div>
          <div className="flex items-center gap-2 opacity-90">
            <span className="hidden sm:inline">কল · ১৬২৬৩</span>
            <Bell size={15} className="opacity-80" />
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="mx-auto max-w-md px-4 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-red-600 text-white shadow-sm shadow-red-600/30">
              <span className="text-lg">🍽️</span>
            </div>
            <div>
              <p className="text-[11px] font-medium uppercase tracking-wider text-slate-500">Welcome to</p>
              <h1 className="text-[17px] font-bold leading-tight text-white">ROOFTOP Restaurant</h1>
            </div>
          </div>
          <button
            onClick={onOpenCart}
            aria-label="কার্ট খুলুন"
            className="relative grid h-11 w-11 place-items-center rounded-2xl bg-slate-900 text-white shadow-sm ring-1 ring-white/10 transition active:scale-95 hover:bg-slate-800"
          >
            <ShoppingBag size={20} />
            {totalItems > 0 && (
              <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-[20px] place-items-center rounded-full bg-red-600 px-1 text-[11px] font-bold text-white">
                {totalItems}
              </span>
            )}
          </button>
        </div>

        {/* Location + status */}
        <div className="mt-3 flex items-center justify-between rounded-2xl bg-slate-900 p-2.5 shadow-sm ring-1 ring-white/10">
          <div className="flex items-center gap-2 text-[12px] text-slate-300">
            <MapPin size={14} className="text-red-500" />
            <span>গুলশান, ঢাকা</span>
            <ChevronRight size={14} className="text-slate-500" />
          </div>
          <div className="flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[11px] font-semibold text-emerald-400">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            এখন খোলা
          </div>
        </div>

        {/* Search */}
        <div className="mt-3 flex items-center gap-2 rounded-2xl bg-slate-900 px-3.5 py-3 shadow-sm ring-1 ring-white/10 focus-within:ring-2 focus-within:ring-red-500/50">
          <Search size={18} className="text-slate-500" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="খাবার খুঁজুন..."
            className="flex-1 bg-transparent text-[14px] text-slate-100 placeholder:text-slate-500 focus:outline-none"
            aria-label="সার্চ"
          />
        </div>

        {/* Category chips */}
        <div className="no-scrollbar -mx-4 mt-4 flex gap-2 overflow-x-auto px-4 pb-1">
          {CATEGORIES.map((cat) => {
            const active = category === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-medium transition active:scale-95 ${
                  active
                    ? "bg-white text-slate-900 shadow-sm"
                    : "bg-slate-900 text-slate-300 ring-1 ring-white/10 hover:bg-slate-800"
                }`}
              >
                <span className="text-[15px]">{cat.emoji}</span>
                <span>{cat.name}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Today's special hero banner */}
      <section className="mx-auto mt-5 max-w-md px-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-500 via-orange-500 to-red-500 p-5 text-white shadow-lg shadow-orange-500/20">
          <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/15 blur-xl" />
          <div className="absolute -bottom-10 -left-10 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
          <div className="relative z-10">
            <p className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-0.5 text-[11px] font-semibold backdrop-blur-sm">
              🔥 আজকের ডিল
            </p>
            <h2 className="mt-2 text-xl font-bold leading-tight">২০% ছাড় পান প্রতিটি পিজ্জায়</h2>
            <p className="mt-1 text-[12px] text-white/85">শুধু আজকের জন্য · কোড: PIZZA20</p>
            <button className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-[12px] font-bold text-orange-600 transition active:scale-95">
              অর্ডার করুন <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </section>

      {/* Today's specials list */}
      <section className="mx-auto mt-5 max-w-md px-4">
        <div className="mb-3 flex items-end justify-between">
          <div>
            <h2 className="text-[17px] font-bold text-white">আজকের স্পেশাল</h2>
            <p className="text-[12px] text-slate-500">তাজা তৈরি · সরাসরি রান্নাঘর থেকে</p>
          </div>
          <button className="text-[13px] font-semibold text-red-500">
            সব দেখুন
          </button>
        </div>

        <div className="flex flex-col gap-3">
          {filtered.length === 0 ? (
            <div className="grid place-items-center rounded-2xl bg-slate-900 p-8 text-center ring-1 ring-white/10">
              <p className="text-3xl">🔍</p>
              <p className="mt-2 text-[14px] font-medium text-slate-300">কোন খাবার পাওয়া যায়নি</p>
              <p className="text-[12px] text-slate-500">অন্য কিছু সার্চ করে দেখুন</p>
            </div>
          ) : (
            filtered.map((item, idx) => (
              <MenuCard
                key={item.id}
                item={item}
                inCart={cart[item.id] || 0}
                onAdd={() => onAdd(item.id)}
                onOpen={() => onOpenProduct(item.id)}
                index={idx}
              />
            ))
          )}
        </div>
      </section>
    </div>
  );
}

function MenuCard({
  item,
  inCart,
  onAdd,
  onOpen,
  index,
}: {
  item: MenuItem;
  inCart: number;
  onAdd: () => void;
  onOpen: () => void;
  index: number;
}) {
  const tag = item.tag ? TAG_MAP[item.tag] : null;
  return (
    <article
      className="animate-float-in flex gap-3 rounded-2xl bg-slate-900 p-3 shadow-sm ring-1 ring-white/10 transition hover:bg-slate-800/80 hover:ring-white/15"
      style={{ animationDelay: `${index * 60}ms`, animationFillMode: "both" }}
    >
      {/* Image — clickable */}
      <button
        onClick={onOpen}
        aria-label={`${item.name} বিস্তারিত দেখুন`}
        className="group relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-slate-800 ring-1 ring-white/10"
      >
        <Image
          src={item.image}
          alt={item.nameEn}
          fill
          sizes="96px"
          className="object-cover transition duration-300 group-active:scale-105"
          unoptimized
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 transition group-hover:opacity-100" />
        <div className="pointer-events-none absolute bottom-1 right-1 grid h-6 w-6 place-items-center rounded-full bg-white/95 text-[10px] font-bold text-slate-900 opacity-0 shadow-md transition group-hover:opacity-100">
          <Search size={11} />
        </div>
        {tag && (
          <span className={`absolute left-1 top-1 rounded-md ${tag.color} px-1.5 py-0.5 text-[9px] font-bold text-white shadow-sm`}>
            {tag.label}
          </span>
        )}
      </button>

      {/* Details — also clickable to open detail */}
      <div
        className="flex min-w-0 flex-1 cursor-pointer flex-col"
        onClick={onOpen}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onOpen();
          }
        }}
      >
        <div className="flex items-start justify-between gap-2">
          <h3 className="truncate text-[14px] font-bold text-white">{item.name}</h3>
          <div className="flex items-center gap-0.5 text-[11px] font-semibold text-amber-400">
            <StarIcon size={11} />
            <span className="text-slate-400">{item.rating.toFixed(1)}</span>
          </div>
        </div>

        <p className="mt-0.5 line-clamp-2 text-[11.5px] leading-snug text-slate-400">{item.desc}</p>

        <div className="mt-auto flex items-center justify-between pt-2">
          <div className="flex items-baseline gap-1.5">
            <span className="text-[15px] font-bold text-white">{formatTaka(item.price)}</span>
            <span className="flex items-center gap-0.5 text-[10px] text-slate-500">
              <ClockIcon size={11} /> {item.prepTime}
            </span>
          </div>

          {inCart > 0 ? (
            <div className="flex items-center gap-2 rounded-full bg-red-500/15 px-2 py-1 text-[12px] font-bold text-red-400 ring-1 ring-red-500/20">
              <span>×{inCart}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAdd();
                }}
                aria-label="আরও যোগ করুন"
                className="grid h-6 w-6 place-items-center rounded-full bg-red-600 text-white transition active:scale-90"
              >
                <Plus size={13} />
              </button>
            </div>
          ) : (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAdd();
              }}
              aria-label={`${item.name} কার্টে যোগ করুন`}
              className="grid h-9 w-9 place-items-center rounded-xl bg-red-600 text-white shadow-sm shadow-red-600/30 transition active:scale-90 hover:bg-red-700"
            >
              <Plus size={18} />
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
