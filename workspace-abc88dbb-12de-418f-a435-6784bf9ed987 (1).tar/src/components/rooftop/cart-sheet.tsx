"use client";

import * as React from "react";
import Image from "next/image";
import { X, Plus, Minus, ShoppingBag, User, Phone, Hash, MessageSquare, ChevronRight } from "lucide-react";
import { MENU_ITEMS, formatTaka } from "@/lib/menu-data";

export type OrderForm = {
  name: string;
  phone: string;
  table: string;
  notes: string;
};

type Props = {
  open: boolean;
  cart: Record<number, number>;
  form: OrderForm;
  onFormChange: (patch: Partial<OrderForm>) => void;
  onInc: (id: number) => void;
  onDec: (id: number) => void;
  onClose: () => void;
  onPlaceOrder: () => void;
  placing?: boolean;
};

export function CartSheet({ open, cart, form, onFormChange, onInc, onDec, onClose, onPlaceOrder, placing }: Props) {
  const items = React.useMemo(
    () =>
      Object.entries(cart)
        .filter(([, q]) => q > 0)
        .map(([id, q]) => {
          const item = MENU_ITEMS.find((m) => m.id === Number(id));
          return item ? { item, qty: q } : null;
        })
        .filter((x): x is { item: (typeof MENU_ITEMS)[number]; qty: number } => x !== null),
    [cart]
  );

  const subtotal = React.useMemo(
    () => items.reduce((sum, { item, qty }) => sum + item.price * qty, 0),
    [items]
  );
  const deliveryFee = subtotal >= 500 || subtotal === 0 ? 0 : 40;
  const total = subtotal + deliveryFee;

  const formValid =
    form.name.trim().length >= 2 &&
    /^01\d{9}$/.test(form.phone.trim()) &&
    form.table.trim().length >= 1;

  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-md"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Sheet */}
      <div className="animate-slide-up relative z-10 flex max-h-[92vh] w-full max-w-md flex-col overflow-hidden rounded-t-3xl bg-slate-900 text-white shadow-2xl ring-1 ring-white/10 sm:rounded-3xl">
        {/* Drag handle */}
        <div className="grid place-items-center pt-2.5">
          <div className="h-1.5 w-10 rounded-full bg-slate-700" />
        </div>

        {/* Header */}
        <header className="flex items-center justify-between px-5 pb-3 pt-3">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-red-500/15 text-red-400 ring-1 ring-red-500/20">
              <ShoppingBag size={18} />
            </div>
            <div>
              <h2 className="text-[16px] font-bold text-white">আপনার অর্ডার</h2>
              <p className="text-[11px] text-slate-400">{items.length} টি আইটেম</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="বন্ধ করুন"
            className="grid h-9 w-9 place-items-center rounded-full bg-slate-800 text-slate-300 transition active:scale-90 hover:bg-slate-700"
          >
            <X size={18} />
          </button>
        </header>

        {/* Body */}
        <div className="custom-scrollbar flex-1 overflow-y-auto px-5">
          {items.length === 0 ? (
            <div className="grid place-items-center py-12 text-center">
              <div className="grid h-16 w-16 place-items-center rounded-full bg-slate-800 text-3xl">🛒</div>
              <p className="mt-3 text-[14px] font-semibold text-slate-200">কার্ট খালি</p>
              <p className="text-[12px] text-slate-500">মেনু থেকে খাবার যোগ করুন</p>
            </div>
          ) : (
            <>
              {/* Items */}
              <ul className="flex flex-col gap-2.5 pb-4">
                {items.map(({ item, qty }) => (
                  <li
                    key={item.id}
                    className="flex gap-3 rounded-2xl bg-slate-800/60 p-2.5 ring-1 ring-white/5"
                  >
                    <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-slate-700">
                      <Image src={item.image} alt={item.nameEn} fill sizes="64px" className="object-cover" unoptimized />
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <h3 className="truncate text-[13.5px] font-bold text-white">{item.name}</h3>
                      <p className="text-[11.5px] text-slate-400">{formatTaka(item.price)} / প্রতিটি</p>
                      <div className="mt-auto flex items-center justify-between">
                        <span className="text-[14px] font-bold text-white">{formatTaka(item.price * qty)}</span>
                        <div className="flex items-center gap-2 rounded-full bg-slate-900 p-0.5 ring-1 ring-white/10">
                          <button
                            onClick={() => onDec(item.id)}
                            aria-label={`কমান ${item.name}`}
                            className="grid h-7 w-7 place-items-center rounded-full bg-slate-800 text-slate-300 transition active:scale-90 hover:bg-slate-700"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="min-w-[20px] text-center text-[13px] font-bold text-white">{qty}</span>
                          <button
                            onClick={() => onInc(item.id)}
                            aria-label={`বাড়ান ${item.name}`}
                            className="grid h-7 w-7 place-items-center rounded-full bg-red-600 text-white transition active:scale-90 hover:bg-red-700"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>

              {/* Form */}
              <div className="rounded-2xl border border-white/5 bg-slate-800/40 p-3">
                <p className="mb-2.5 text-[12px] font-bold uppercase tracking-wider text-slate-400">ডেলিভারি তথ্য</p>

                <Field label="আপনার নাম" icon={<User size={14} />} required>
                  <input
                    value={form.name}
                    onChange={(e) => onFormChange({ name: e.target.value })}
                    placeholder="আপনার নাম লিখুন"
                    className="w-full bg-transparent text-[13.5px] text-slate-100 placeholder:text-slate-500 focus:outline-none"
                  />
                </Field>

                <Field label="মোবাইল নম্বর" icon={<Phone size={14} />} required>
                  <input
                    value={form.phone}
                    onChange={(e) => onFormChange({ phone: e.target.value })}
                    inputMode="tel"
                    placeholder="01XXXXXXXXX"
                    className="w-full bg-transparent text-[13.5px] text-slate-100 placeholder:text-slate-500 focus:outline-none"
                  />
                </Field>

                <Field label="টেবিল নম্বর" icon={<Hash size={14} />} required>
                  <input
                    value={form.table}
                    onChange={(e) => onFormChange({ table: e.target.value })}
                    placeholder="T-05"
                    className="w-full bg-transparent text-[13.5px] text-slate-100 placeholder:text-slate-500 focus:outline-none"
                  />
                </Field>

                <Field label="বিশেষ নির্দেশ (ঐচ্ছিক)" icon={<MessageSquare size={14} />}>
                  <textarea
                    value={form.notes}
                    onChange={(e) => onFormChange({ notes: e.target.value })}
                    placeholder="অতিরিক্ত তথ্য যদি থাকে..."
                    rows={2}
                    className="w-full resize-none bg-transparent text-[13.5px] text-slate-100 placeholder:text-slate-500 focus:outline-none"
                  />
                </Field>
              </div>
            </>
          )}
        </div>

        {/* Footer with totals + CTA */}
        {items.length > 0 && (
          <footer className="border-t border-white/5 bg-slate-900/95 px-5 pb-5 pt-3">
            <div className="flex flex-col gap-1 text-[12.5px]">
              <div className="flex items-center justify-between text-slate-400">
                <span>সাবটোটাল</span>
                <span className="font-medium text-slate-200">{formatTaka(subtotal)}</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>ডেলিভারি ফি</span>
                <span className="font-medium text-slate-200">
                  {deliveryFee === 0 ? <span className="text-emerald-400">ফ্রি</span> : formatTaka(deliveryFee)}
                </span>
              </div>
              <div className="mt-1 flex items-center justify-between border-t border-dashed border-white/10 pt-2">
                <span className="text-[14px] font-bold text-white">মোট</span>
                <span className="text-[18px] font-extrabold text-amber-400">{formatTaka(total)}</span>
              </div>
            </div>

            <button
              onClick={onPlaceOrder}
              disabled={!formValid || placing}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-red-600 py-3.5 text-[15px] font-bold text-white shadow-lg shadow-red-600/30 transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none"
            >
              {placing ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                  অর্ডার করা হচ্ছে...
                </>
              ) : (
                <>
                  অর্ডার দিন
                  <ChevronRight size={18} />
                </>
              )}
            </button>
            {!formValid && (
              <p className="mt-2 text-center text-[11px] text-slate-500">
                অনুগ্রহ করে নাম, মোবাইল ও টেবিল নম্বর পূরণ করুন
              </p>
            )}
          </footer>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  icon,
  required,
  children,
}: {
  label: string;
  icon: React.ReactNode;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="mb-2 flex flex-col gap-1">
      <span className="flex items-center gap-1.5 text-[11px] font-medium text-slate-400">
        <span className="text-slate-500">{icon}</span>
        {label}
        {required && <span className="text-red-400">*</span>}
      </span>
      <div className="rounded-xl bg-slate-900 px-3 py-2 ring-1 ring-white/10 focus-within:ring-2 focus-within:ring-red-500/50">
        {children}
      </div>
    </label>
  );
}
