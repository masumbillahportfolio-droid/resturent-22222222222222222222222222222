"use client";

import * as React from "react";
import Image from "next/image";
import { Check, Home, RotateCcw } from "lucide-react";
import { formatTaka, MENU_ITEMS } from "@/lib/menu-data";
import { WhatsAppIcon } from "./icons";

export type PlacedOrder = {
  orderNumber: string;
  items: { id: number; qty: number }[];
  total: number;
  name: string;
  table: string;
};

type Props = {
  order: PlacedOrder | null;
  onClose: () => void;
};

export function SuccessModal({ order, onClose }: Props) {
  if (!order) return null;

  const items = order.items
    .map((it) => {
      const m = MENU_ITEMS.find((x) => x.id === it.id);
      return m ? { item: m, qty: it.qty } : null;
    })
    .filter(Boolean) as { item: (typeof MENU_ITEMS)[number]; qty: number }[];

  const waText = encodeURIComponent(
    `আসসালামু আলাইকুম, আমার অর্ডার #${order.orderNumber}\n` +
      items.map((i) => `• ${i.item.name} × ${i.qty}`).join("\n") +
      `\nমোট: ${formatTaka(order.total)}\nনাম: ${order.name} · টেবিল: ${order.table}`
  );
  const waUrl = `https://wa.me/8801626300000?text=${waText}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Dark backdrop */}
      <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-md" />

      {/* Card */}
      <div className="animate-pop-in relative z-10 mx-4 w-full max-w-sm overflow-hidden rounded-3xl bg-slate-900 text-white shadow-2xl ring-1 ring-white/10">
        {/* Top accent */}
        <div className="pointer-events-none absolute -top-20 left-1/2 h-44 w-44 -translate-x-1/2 rounded-full bg-emerald-500/20 blur-3xl" />

        <div className="relative px-6 pb-6 pt-9 text-center">
          {/* Check icon */}
          <div className="animate-check-pop mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-lg shadow-emerald-500/40">
            <Check size={42} strokeWidth={3} className="text-white" />
          </div>

          <h2 className="mt-5 text-[22px] font-bold">অর্ডার সফল!</h2>
          <p className="mt-1.5 text-[13px] leading-relaxed text-slate-300">
            আপনার অর্ডার পাঠানো হয়েছে। অনুগ্রহ করে ধৈর্য ধরুন,
            <br /> আমরা দ্রুত প্রস্তুত করছি।
          </p>

          {/* Order number */}
          <div className="mt-5 rounded-2xl bg-slate-800/80 p-4 ring-1 ring-white/5">
            <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400">অর্ডার নম্বর</p>
            <p className="mt-1 text-[26px] font-extrabold text-amber-400">#{order.orderNumber}</p>
            <div className="mt-2 flex items-center justify-center gap-1.5 text-[11.5px] text-slate-300">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-400" />
              রান্নাঘরে প্রস্তুত হচ্ছে...
            </div>
          </div>

          {/* Items summary */}
          <div className="mt-4 space-y-2 text-left">
            {items.map(({ item, qty }) => (
              <div key={item.id} className="flex items-center gap-2.5 rounded-xl bg-slate-800/60 p-2 ring-1 ring-white/5">
                <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-slate-700">
                  <Image src={item.image} alt={item.nameEn} fill sizes="40px" className="object-cover" unoptimized />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-semibold text-white">{item.name}</p>
                  <p className="text-[10.5px] text-slate-400">× {qty}</p>
                </div>
                <span className="text-[12.5px] font-bold text-amber-400">{formatTaka(item.price * qty)}</span>
              </div>
            ))}
            <div className="flex items-center justify-between rounded-xl bg-amber-500/10 p-2.5 text-amber-300 ring-1 ring-amber-500/20">
              <span className="text-[12.5px] font-medium">মোট পরিশোধ্য</span>
              <span className="text-[15px] font-extrabold text-amber-400">{formatTaka(order.total)}</span>
            </div>
          </div>

          {/* WhatsApp CTA */}
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 flex w-full items-center justify-center gap-2.5 rounded-2xl bg-red-600 py-3.5 text-[15px] font-bold text-white shadow-lg shadow-red-600/30 transition active:scale-[0.98] hover:bg-red-700"
          >
            <WhatsAppIcon size={20} />
            আপনার অর্ডার গ্রুপ
          </a>

          {/* Secondary actions */}
          <div className="mt-3 flex gap-2">
            <button
              onClick={onClose}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-2xl bg-slate-800 py-2.5 text-[12.5px] font-semibold text-slate-200 ring-1 ring-white/5 transition active:scale-[0.98] hover:bg-slate-700"
            >
              <Home size={15} /> হোম
            </button>
            <button
              onClick={onClose}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-2xl bg-slate-800 py-2.5 text-[12.5px] font-semibold text-slate-200 ring-1 ring-white/5 transition active:scale-[0.98] hover:bg-slate-700"
            >
              <RotateCcw size={15} /> নতুন অর্ডার
            </button>
          </div>

          <p className="mt-4 text-[10.5px] leading-relaxed text-slate-500">
            সাপোর্ট · ১৬২৬৩ · ROOFTOP Restaurant
          </p>
        </div>
      </div>
    </div>
  );
}
