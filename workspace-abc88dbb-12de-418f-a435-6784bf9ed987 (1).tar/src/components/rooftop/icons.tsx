import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number };

export function WhatsAppIcon({ size = 24, ...props }: Props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="currentColor"
      aria-hidden="true"
      {...props}
    >
      <path d="M.057 24l1.687-6.163a11.867 11.867 0 01-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 018.413 3.488 11.824 11.824 0 013.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 01-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 001.51 5.26l-.999 3.648 3.978-1.245zm5.485-7.989c-.224-.045-.498-.067-.66-.235-.183-.184-.299-.498-.299-.498s-.075.045-.183.183c-.108.139-.299.43-.299.43s-.235.324-.025.726c.21.402.766 1.078 1.65 1.434.884.356 1.434.356 1.65.356.215 0 .477-.108.545-.21.067-.103.123-.246.156-.358.033-.111.058-.27.058-.27s-.13-.139-.354-.27c-.224-.13-.49-.27-.49-.27s-.158-.078-.35-.078zm1.46-3.41c-.425-.425-1.063-.653-1.86-.653h-.001c-.798 0-1.435.228-1.86.653-.425.425-.641 1.04-.641 1.731 0 .34.073.553.183.81.108.25.27.498.43.81.16.312.312.653.312 1.046 0 .395-.16.732-.345.97-.183.235-.42.396-.658.518-.235.123-.47.21-.654.27-.183.063-.312.103-.312.103s.13.04.354.067c.224.027.55.045.925-.027.375-.072.81-.235 1.232-.621.42-.386.81-.995.81-1.96 0-.487-.13-.81-.27-1.078-.139-.27-.299-.498-.43-.81-.16-.312-.312-.653-.312-1.046 0-.395.16-.732.345-.97.183-.235.42-.396.658-.518.235-.123.47-.21.654-.27.183-.063.312-.103.312-.103s-.13-.04-.354-.067c-.224-.027-.55-.045-.925.027-.375.072-.81.235-1.232.621-.42.386-.81.995-.81 1.96z" />
    </svg>
  );
}

export function BikeIcon({ size = 24, ...props }: Props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      <circle cx="5.5" cy="17.5" r="3.5" />
      <circle cx="18.5" cy="17.5" r="3.5" />
      <path d="M15 6a1 1 0 100 2h3a1 1 0 011 1v4" />
      <path d="M12 17.5V14l-3-3 4-3 2 3h2" />
    </svg>
  );
}

export function ClockIcon({ size = 24, ...props }: Props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </svg>
  );
}

export function StarIcon({ size = 24, ...props }: Props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="currentColor"
      aria-hidden="true"
      {...props}
    >
      <path d="M12 2l2.94 5.96 6.6.96-4.78 4.66 1.13 6.58L12 17.6 6.1 20.16l1.13-6.58L2.46 8.92l6.6-.96L12 2z" />
    </svg>
  );
}
