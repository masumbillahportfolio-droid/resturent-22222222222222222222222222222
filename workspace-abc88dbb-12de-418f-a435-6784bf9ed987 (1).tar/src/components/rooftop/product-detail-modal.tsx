"use client";

import * as React from "react";
import Image from "next/image";
import { X, Plus, Minus, Star, Clock, ShoppingBag, Flame, Check } from "lucide-react";
import { formatTaka, TAG_MAP, type MenuItem } from "@/lib/menu-data";
import { StarIcon, ClockIcon } from "./icons";

type Props = {
  item: MenuItem | null;
  qtyInCart: number;
  onClose: () => void;
  onAdd: (id: number) => void;
  onInc: (id: number) => void;
  onDec: (id: number) => void;
};

export function ProductDetailModal({ item, qtyInCart, onClose, onAdd, onInc, onDec }: Props) {
  const [localQty, setLocalQty] = React.useState(1);

  React.useEffect(() => {
    if (item) setLocalQty(1);
  }, [item?.id]);

  React.useEffect(() => {
    if (!item) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [item, onClose]);

  if (!item) return null;
  const tag = item.tag ? TAG_MAP[item.tag] : null;

  const handleAdd = () => {
    for (let i = 0; i < localQty; i++) onAdd(item.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose} aria-hidden="true" />

      <div className="animate-slide-up relative z-10 flex max-h-[94vh] w-full max-w-md flex-col overflow-hidden rounded-t-3xl bg-slate-900 text-white shadow-2xl ring-1 ring-white/10 sm:rounded-3xl">
        {/* Hero image */}
        <div className="relative h-64 w-full shrink-0 overflow-hidden bg-slate-800">
          <Image src={item.image} alt={item.nameEn} fill sizes="(max-width: 768px) 100vw, 448px" className="object-cover" unoptimized priority />

          {/* Top overlay with close + tag */}
          <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
            {tag ? (
              <span className={`rounded-full ${tag.color} px-2.5 py-1 text-[11px] font-bold text-white shadow-md backdrop-blur-sm`}>
                {tag.label}
              </span>
            ) : (
              <span />
            )}
            <button
              onClick={onClose}
              aria-label="বন্ধ করুন"
              className="grid h-9 w-9 place-items-center rounded-full bg-slate-950/60 text-white ring-1 ring-white/15 backdrop-blur-md transition active:scale-90 hover:bg-slate-950/80"
            >
              <X size={18} />
            </button>
          </div>

          {/* Gradient fade into the card */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent" />
        </div>

        {/* Body */}
        <div className="custom-scrollbar flex-1 overflow-y-auto px-5 pb-4 pt-3">
          {/* Title + rating */}
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h2 className="text-[20px] font-bold leading-tight text-white">{item.name}</h2>
              <p className="mt-0.5 text-[12.5px] text-slate-400">{item.nameEn}</p>
            </div>
            <div className="flex items-center gap-1 rounded-full bg-amber-500/15 px-2.5 py-1 text-[12px] font-bold text-amber-400 ring-1 ring-amber-500/25">
              <StarIcon size={12} />
              {item.rating.toFixed(1)}
            </div>
          </div>

          {/* Quick stats */}
          <div className="mt-3 flex items-center gap-2 text-[12px] text-slate-300">
            <span className="flex items-center gap-1.5 rounded-full bg-slate-800/70 px-2.5 py-1 ring-1 ring-white/5">
              <ClockIcon size={12} className="text-emerald-400" /> প্রস্তুতি: {item.prepTime}
            </span>
            <span className="flex items-center gap-1.5 rounded-full bg-slate-800/70 px-2.5 py-1 ring-1 ring-white/5">
              <Flame size={12} className="text-amber-400" /> তাজা রান্না
            </span>
          </div>

          {/* Description */}
          <div className="mt-4">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-500">বিবরণ</h3>
            <p className="mt-1.5 text-[13.5px] leading-relaxed text-slate-300">{item.desc}</p>
            <p className="mt-2 text-[13px] leading-relaxed text-slate-400">
              আমাদের স্বাদিষ্ট {item.nameEn} তাজা উপকরণ দিয়ে তৈরি এবং প্রতিটি অর্ডারে প্রস্তুত করা হয়। হাতে তৈরি রেসিপি, বিশেষ মশলা মিশ্রণ এবং রান্নাঘরের নিয়মিত মান নিয়ন্ত্রণের মাধ্যমে নিশ্চিত করা হয় যে আপনি সর্বোচ্চ মানের স্বাদ পাচ্ছেন।
            </p>
          </div>

          {/* Ingredients highlights */}
          <div className="mt-4">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-500">কি কি আছে</h3>
            <ul className="mt-2 grid grid-cols-2 gap-1.5 text-[12.5px] text-slate-300">
              {["তাজা উপকরণ", "হাতে তৈরি", "হালাল সার্টিফাইড", "আস্থা নিশ্চয়তা"].map((ing) => (
                <li key={ing} className="flex items-center gap-1.5">
                  <Check size={13} className="shrink-0 text-emerald-400" />
                  {ing}
                </li>
              ))}
            </ul>
          </div>

          {/* If already in cart */}
          {qtyInCart > 0 && (
            <div className="mt-4 flex items-center gap-2 rounded-2xl bg-emerald-500/10 p-3 text-[12.5px] text-emerald-300 ring-1 ring-emerald-500/25">
              <ShoppingBag size={16} className="shrink-0" />
              <span>আপনার কার্টে এই আইটেমটি ইতিমধ্যে <b className="font-bold">{qtyInCart}</b> বার আছে।</span>
            </div>
          )}
        </div>

        {/* Footer: qty selector + add to cart */}
        <footer className="border-t border-white/5 bg-slate-900/95 px-5 pb-5 pt-3 backdrop-blur">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[10.5px] uppercase tracking-wider text-slate-500">মূল্য</p>
              <p className="text-[19px] font-extrabold text-amber-400">{formatTaka(item.price * localQty)}</p>
            </div>

            <div className="flex items-center gap-2 rounded-full bg-slate-800 p-1 ring-1 ring-white/10">
              <button
                onClick={() => setLocalQty((q) => Math.max(1, q - 1))}
                aria-label="পরিমাণ কমান"
                className="grid h-9 w-9 place-items-center rounded-full bg-slate-700 text-white transition active:scale-90 hover:bg-slate-600"
              >
                <Minus size={16} />
              </button>
              <span className="min-w-[28px] text-center text-[15px] font-bold text-white">{localQty}</span>
              <button
                onClick={() => setLocalQty((q) => Math.min(20, q + 1))}
                aria-label="পরিমাণ বাড়ান"
                className="grid h-9 w-9 place-items-center rounded-full bg-red-600 text-white transition active:scale-90 hover:bg-red-700"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>

          <button
            onClick={handleAdd}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-red-600 py-3.5 text-[15px] font-bold text-white shadow-lg shadow-red-600/30 transition active:scale-[0.98] hover:bg-red-700"
          >
            <ShoppingBag size={18} />
            কার্টে যোগ করুন · {formatTaka(item.price * localQty)}
          </button>
        </footer>
      </div>
    </div>
  );
}
