export type CategoryId = "all" | "burger" | "pizza" | "garden" | "dessert" | "drinks" | "chicken";

export type MenuItem = {
  id: number;
  name: string;
  nameEn: string;
  desc: string;
  price: number;
  category: Exclude<CategoryId, "all">;
  image: string;
  tag?: "new" | "featured" | "spicy";
  rating: number;
  prepTime: string;
};

export const CATEGORIES: { id: CategoryId; name: string; nameEn: string; emoji: string }[] = [
  { id: "all", name: "সব", nameEn: "All", emoji: "🍽️" },
  { id: "burger", name: "বার্গার", nameEn: "Burger", emoji: "🍔" },
  { id: "pizza", name: "পিজ্জা", nameEn: "Pizza", emoji: "🍕" },
  { id: "chicken", name: "চিকেন", nameEn: "Chicken", emoji: "🍗" },
  { id: "garden", name: "গার্ডেন", nameEn: "Garden", emoji: "🥗" },
  { id: "dessert", name: "ডেসার্ট", nameEn: "Dessert", emoji: "🍰" },
  { id: "drinks", name: "ড্রিংকস", nameEn: "Drinks", emoji: "🥤" },
];

export const TAG_MAP: Record<NonNullable<MenuItem["tag"]>, { label: string; color: string }> = {
  new: { label: "নতুন", color: "bg-emerald-500" },
  featured: { label: "নির্বাচিত", color: "bg-amber-500" },
  spicy: { label: "মসলাদার", color: "bg-red-500" },
};

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 1,
    name: "নিনজা চিজ বার্গার",
    nameEn: "Ninja Cheese Burger",
    desc: "জুসি বিফ প্যাটি, মেল্টেড চেডার, ক্রিস্পি অনিয়ন, স্পেশাল সস",
    price: 180,
    category: "burger",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/57dd48f683df.jpg",
    tag: "featured",
    rating: 4.8,
    prepTime: "১৫ মিনিট",
  },
  {
    id: 2,
    name: "পেপারোনি পিজ্জা",
    nameEn: "Pepperoni Pizza",
    desc: "হাতে তৈরি ডো, ডবল পেপারোনি, মোজারেলা, অরিগানো",
    price: 280,
    category: "pizza",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/edba335c88e8.jpg",
    tag: "new",
    rating: 4.9,
    prepTime: "২০ মিনিট",
  },
  {
    id: 3,
    name: "ভেজিটেবল সালাদ",
    nameEn: "Vegetable Salad",
    desc: "তাজা শাকসবজি, অলিভ অয়েল, লেমন ভিনাইগ্রেট",
    price: 120,
    category: "garden",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/c4400c9ceaee.jpg",
    rating: 4.5,
    prepTime: "৮ মিনিট",
  },
  {
    id: 4,
    name: "চিকেন বিরিয়ানি",
    nameEn: "Chicken Biryani",
    desc: "বাসমতি চাল, মশলাদার চিকেন, জাফরান, ভুনা পেয়াজ",
    price: 220,
    category: "chicken",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/09d42249d201.jpg",
    tag: "featured",
    rating: 4.7,
    prepTime: "২৫ মিনিট",
  },
  {
    id: 5,
    name: "চকলেট লেয়ার কেক",
    nameEn: "Chocolate Layer Cake",
    desc: "ডার্ক চকলেট গ্যানাশ, মসৃণ ক্রিম, কোকো পাউডার",
    price: 150,
    category: "dessert",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/00280655b4c8.jpg",
    tag: "new",
    rating: 4.9,
    prepTime: "৫ মিনিট",
  },
  {
    id: 6,
    name: "ক্লাসিক মোজিটো",
    nameEn: "Classic Mojito",
    desc: "তাজা পুদিনা, লেবু, চিনি, সোদা ওয়াটার",
    price: 90,
    category: "drinks",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/a61e809432c7.jpg",
    rating: 4.6,
    prepTime: "৫ মিনিট",
  },
  {
    id: 7,
    name: "স্পাইসি বাফেলো উইংস",
    nameEn: "Spicy Buffalo Wings",
    desc: "ক্রিস্পি চিকেন উইংস, হট সস, ব্লু চিজ ড্রেসিং",
    price: 240,
    category: "chicken",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/a0f97918c0f5.jpg",
    tag: "spicy",
    rating: 4.8,
    prepTime: "১৮ মিনিট",
  },
  {
    id: 8,
    name: "ক্রিমি পারমেসান পাস্তা",
    nameEn: "Creamy Parmesan Pasta",
    desc: "আলফ্রেডো সস, পারমেসান, বেসিল, ফেটুচিনি",
    price: 200,
    category: "pizza",
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/528c86a92b34.jpg",
    rating: 4.7,
    prepTime: "২২ মিনিট",
  },
];

export const formatTaka = (amount: number) => `৳${amount}`;
